<?php

/**
 * @file
 * Documentation for pathauto API.
 *
 * @see hook_token_info
 * @see hook_tokens
 */

function hook_path_alias_types() {
}

function hook_pathauto($op) {
}

function hook_pathauto_bulkupdate() {
}

function hook_pathauto_alias_alter(&$alias, $context) {
}
