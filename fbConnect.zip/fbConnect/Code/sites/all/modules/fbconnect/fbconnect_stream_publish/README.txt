/* $Id */

This module allows to publish nodes to user's facebook wall.
To enable it go to admin/content/node-type/<type> and check Facebook Stream Publish section 

Also see alternative module - drupal.org/project/facebook_stream

-------------------------------------------------------------------------------

Posting to Fan Page Wall - http://drupal.org/node/762276#comment-3091102